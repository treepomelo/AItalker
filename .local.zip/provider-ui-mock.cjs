const http = require('http');
http.createServer((req,res)=>{
  let raw=''; req.on('data',chunk=>raw+=chunk); req.on('end',()=>{
    const body=JSON.parse(raw||'{}');
    if(req.headers.authorization!=='Bearer local-ui-test'){res.writeHead(401);res.end();return;}
    if(req.url==='/v1/chat/completions'){
      if(body.stream){res.writeHead(200,{'Content-Type':'text/event-stream'});res.end('data: '+JSON.stringify({choices:[{delta:{content:'Mock connection OK'}}]})+'\n\ndata: [DONE]\n\n');}
      else{res.writeHead(200,{'Content-Type':'application/json'});res.end(JSON.stringify({choices:[{message:{content:'Mock connection OK'}}]}));}
    }else if(req.url==='/v1/audio/speech'){
      res.writeHead(200,{'Content-Type':'audio/mpeg'});res.end(Buffer.from('ID3-local-protocol-fixture'));
    }else{res.writeHead(404);res.end();}
  });
}).listen(18088,'127.0.0.1',()=>console.log('Local UI fixture listening on 18088'));
