"use strict";const t="http://localhost:9000/api".trim().replace(/\/+$/,""),s={baseHttps:t,baseWss:t.replace(/^http/,"ws")};exports.env=s;
